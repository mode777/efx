if (efx.loadText('data.txt') !== 'zip-data\n') { throw new Error('zip load'); }
efx.log('zip-entry-ok');
efx.quit(0);
